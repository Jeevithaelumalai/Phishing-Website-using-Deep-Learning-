"""
PhishGuard - FastAPI Server
Wraps the trained model as a REST API.

Run with:
    uvicorn src.server:app --reload --port 8000
"""

import os
import sys
import time
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl
from contextlib import asynccontextmanager
import tensorflow as tf

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.feature_extractor import extract_features, get_feature_names
from src.model import urls_to_sequences, MODEL_SAVE_PATH


# ── Global model variable ─────────────────────────────────────────────────────
model = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load model on startup, clean up on shutdown."""
    global model
    print("\n🛡️  PhishGuard API starting up...")
    if os.path.exists(MODEL_SAVE_PATH):
        print(f"📦 Loading model from {MODEL_SAVE_PATH}...")
        model = tf.keras.models.load_model(MODEL_SAVE_PATH)
        print("✅ Model loaded successfully!\n")
    else:
        print(f"⚠️  No model found at {MODEL_SAVE_PATH}")
        print("   Run python src/train.py first to train the model.\n")
    yield
    print("👋 PhishGuard API shutting down.")


# ── App Setup ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="PhishGuard API",
    description="Real-time phishing URL detection using Deep Learning",
    version="1.0.0",
    lifespan=lifespan
)

# Allow Chrome extension and local frontend to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to your extension ID
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request / Response Models ─────────────────────────────────────────────────
class URLRequest(BaseModel):
    url: str

    class Config:
        json_schema_extra = {
            "example": {"url": "http://paypal-secure-login.xyz/verify"}
        }


class PredictionResponse(BaseModel):
    url: str
    phishing_probability: float
    label: str                  # "PHISHING" or "LEGITIMATE"
    confidence: float           # 0-100
    risk_level: str             # "HIGH" / "MEDIUM" / "LOW"
    flagged_features: list      # Which features triggered the alert
    inference_time_ms: float    # How long the prediction took


class BatchURLRequest(BaseModel):
    urls: list[str]

    class Config:
        json_schema_extra = {
            "example": {
                "urls": [
                    "https://www.google.com",
                    "http://paypal-secure-login.xyz/verify"
                ]
            }
        }


# ── Helper ────────────────────────────────────────────────────────────────────
def get_risk_level(prob: float) -> str:
    if prob >= 0.75:
        return "HIGH"
    elif prob >= 0.45:
        return "MEDIUM"
    return "LOW"


def predict_single(url: str) -> dict:
    """Run inference on one URL and return full result dict."""
    start = time.time()

    # Extract features
    features = np.array(extract_features(url), dtype=np.float32).reshape(1, -1)
    url_seq = urls_to_sequences([url])

    # Run model
    prob = float(model.predict([url_seq, features], verbose=0)[0][0])

    # Find flagged features
    feat_values = features[0].tolist()
    feat_names = get_feature_names()
    flagged = [feat_names[i] for i, v in enumerate(feat_values) if v > 0.5]

    elapsed_ms = round((time.time() - start) * 1000, 2)

    return {
        "url": url,
        "phishing_probability": round(prob, 4),
        "label": "PHISHING" if prob >= 0.5 else "LEGITIMATE",
        "confidence": round(max(prob, 1 - prob) * 100, 1),
        "risk_level": get_risk_level(prob),
        "flagged_features": flagged,
        "inference_time_ms": elapsed_ms,
    }


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "name": "PhishGuard API",
        "version": "1.0.0",
        "status": "running",
        "model_loaded": model is not None,
        "endpoints": {
            "predict": "POST /predict",
            "batch":   "POST /predict/batch",
            "health":  "GET  /health",
            "docs":    "GET  /docs",
        }
    }


@app.get("/health")
def health():
    """Health check — used by Chrome extension to verify server is up."""
    return {
        "status": "ok",
        "model_loaded": model is not None
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(request: URLRequest):
    """
    Predict whether a single URL is phishing or legitimate.

    Returns probability score, risk level, and which features triggered.
    """
    if model is None:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Run python src/train.py first."
        )

    if not request.url.startswith(("http://", "https://")):
        raise HTTPException(
            status_code=400,
            detail="URL must start with http:// or https://"
        )

    try:
        result = predict_single(request.url)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")


@app.post("/predict/batch")
def predict_batch(request: BatchURLRequest):
    """
    Predict multiple URLs at once (max 50).
    """
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded.")

    if len(request.urls) > 50:
        raise HTTPException(status_code=400, detail="Max 50 URLs per batch.")

    results = []
    for url in request.urls:
        try:
            results.append(predict_single(url))
        except Exception as e:
            results.append({"url": url, "error": str(e)})

    phishing_count = sum(1 for r in results if r.get("label") == "PHISHING")

    return {
        "total": len(results),
        "phishing_found": phishing_count,
        "legitimate_found": len(results) - phishing_count,
        "results": results
    }


@app.get("/features")
def list_features():
    """Returns the 30 feature names used by the model — useful for explainability."""
    return {
        "count": 30,
        "features": get_feature_names()
    }
