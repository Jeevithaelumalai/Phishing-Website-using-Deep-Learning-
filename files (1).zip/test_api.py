"""
PhishGuard - API Tester
Run this AFTER starting the server to verify everything works.

Usage:
    python src/test_api.py
"""

import requests
import json

BASE_URL = "http://localhost:8000"

# ── Test URLs ─────────────────────────────────────────────────────────────────
TEST_URLS = [
    # Legitimate
    "https://www.google.com/search?q=weather",
    "https://www.github.com/microsoft/vscode",
    "https://stackoverflow.com/questions/tagged/python",

    # Phishing (fake examples)
    "http://paypal-secure-login.xyz/verify/account?id=123",
    "http://192.168.1.1/login.php",
    "http://google.com.fake-verify.tk/update",
    "http://secure-amazon-login.ml/signin",
]


def print_result(result: dict):
    label = result.get("label", "ERROR")
    prob  = result.get("phishing_probability", 0)
    risk  = result.get("risk_level", "?")
    conf  = result.get("confidence", 0)
    url   = result.get("url", "")[:60]

    icon = "🔴" if label == "PHISHING" else "🟢"
    print(f"\n  {icon} {label} ({risk} risk, {conf}% confidence)")
    print(f"     URL:   {url}")
    print(f"     Score: {prob:.4f}")
    if result.get("flagged_features"):
        print(f"     Flags: {', '.join(result['flagged_features'][:4])}")


def main():
    print("\n" + "="*55)
    print("  🛡️  PhishGuard API - Test Suite")
    print("="*55)

    # 1. Health check
    print("\n[1] Health check...")
    try:
        r = requests.get(f"{BASE_URL}/health", timeout=3)
        data = r.json()
        if data.get("status") == "ok" and data.get("model_loaded"):
            print("  ✅ Server is up and model is loaded!")
        elif data.get("status") == "ok":
            print("  ⚠️  Server is up but model not loaded. Run train.py first.")
            return
        else:
            print("  ❌ Server returned unexpected response.")
            return
    except requests.exceptions.ConnectionError:
        print("  ❌ Cannot connect to server.")
        print("     Make sure you started it with:")
        print("     uvicorn src.server:app --reload --port 8000")
        return

    # 2. Single URL prediction
    print("\n[2] Single URL predictions...")
    for url in TEST_URLS:
        r = requests.post(f"{BASE_URL}/predict", json={"url": url})
        print_result(r.json())

    # 3. Batch prediction
    print("\n\n[3] Batch prediction (all URLs at once)...")
    r = requests.post(f"{BASE_URL}/predict/batch", json={"urls": TEST_URLS})
    data = r.json()
    print(f"  Total:      {data['total']}")
    print(f"  Phishing:   {data['phishing_found']}")
    print(f"  Legitimate: {data['legitimate_found']}")

    print("\n✅ All tests passed! API is working correctly.\n")


if __name__ == "__main__":
    main()
