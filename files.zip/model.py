"""
PhishGuard - Deep Learning Model
Hybrid CNN + LSTM model for phishing URL detection.
Takes BOTH raw URL characters AND extracted features as input.
"""

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, Model
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
import os


# ── Constants ────────────────────────────────────────────────────────────────
MAX_URL_LENGTH = 200       # Max chars from URL for char-level CNN
VOCAB_SIZE = 128           # ASCII chars
EMBEDDING_DIM = 64
NUM_FEATURES = 30          # Engineered features from feature_extractor.py
MODEL_SAVE_PATH = "models/phishguard_model.keras"


# ── Character Tokenizer ───────────────────────────────────────────────────────
def url_to_sequence(url: str, max_len: int = MAX_URL_LENGTH) -> np.ndarray:
    """Convert URL string to padded integer sequence (char-level)."""
    seq = [ord(c) % VOCAB_SIZE for c in url[:max_len]]
    # Pad or truncate to max_len
    if len(seq) < max_len:
        seq = seq + [0] * (max_len - len(seq))
    return np.array(seq, dtype=np.int32)


def urls_to_sequences(urls, max_len: int = MAX_URL_LENGTH) -> np.ndarray:
    return np.array([url_to_sequence(u, max_len) for u in urls])


# ── Model Architecture ────────────────────────────────────────────────────────
def build_model(num_features: int = NUM_FEATURES) -> Model:
    """
    Dual-input model:
      - Branch A: Char-level CNN → captures character patterns (e.g. "%20", "login", IP)
      - Branch B: Engineered features → numerical signals
    Both branches merge → dense layers → binary output
    """

    # ── Branch A: URL Character Sequence ────────────────────────────────────
    url_input = keras.Input(shape=(MAX_URL_LENGTH,), name="url_chars")

    x = layers.Embedding(
        input_dim=VOCAB_SIZE,
        output_dim=EMBEDDING_DIM,
        input_length=MAX_URL_LENGTH,
        name="char_embedding"
    )(url_input)

    # Multi-scale convolutions (captures n-gram patterns at different scales)
    conv3 = layers.Conv1D(128, 3, activation="relu", padding="same")(x)
    conv5 = layers.Conv1D(128, 5, activation="relu", padding="same")(x)
    conv7 = layers.Conv1D(64,  7, activation="relu", padding="same")(x)

    # Pool each
    pool3 = layers.GlobalMaxPooling1D()(conv3)
    pool5 = layers.GlobalMaxPooling1D()(conv5)
    pool7 = layers.GlobalMaxPooling1D()(conv7)

    # LSTM on top of embeddings — captures sequential context
    lstm_out = layers.Bidirectional(
        layers.LSTM(64, return_sequences=False)
    )(x)

    # Combine CNN multi-scale + LSTM
    char_branch = layers.Concatenate(name="char_features")(
        [pool3, pool5, pool7, lstm_out]
    )
    char_branch = layers.Dense(128, activation="relu")(char_branch)
    char_branch = layers.Dropout(0.3)(char_branch)

    # ── Branch B: Engineered Features ────────────────────────────────────────
    feat_input = keras.Input(shape=(num_features,), name="engineered_features")

    y = layers.Dense(64, activation="relu")(feat_input)
    y = layers.BatchNormalization()(y)
    y = layers.Dense(64, activation="relu")(y)
    y = layers.Dropout(0.3)(y)

    # ── Merge Branches ────────────────────────────────────────────────────────
    merged = layers.Concatenate(name="merged")([char_branch, y])
    merged = layers.Dense(128, activation="relu")(merged)
    merged = layers.Dropout(0.4)(merged)
    merged = layers.Dense(64, activation="relu")(merged)

    # ── Output ────────────────────────────────────────────────────────────────
    output = layers.Dense(1, activation="sigmoid", name="phishing_prob")(merged)

    model = Model(
        inputs=[url_input, feat_input],
        outputs=output,
        name="PhishGuard_v1"
    )

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=[
            "accuracy",
            keras.metrics.AUC(name="auc"),
            keras.metrics.Precision(name="precision"),
            keras.metrics.Recall(name="recall"),
        ]
    )

    return model


# ── Training Callbacks ────────────────────────────────────────────────────────
def get_callbacks(model_path: str = MODEL_SAVE_PATH):
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    return [
        EarlyStopping(
            monitor="val_auc",
            patience=5,
            restore_best_weights=True,
            mode="max",
            verbose=1
        ),
        ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=3,
            min_lr=1e-6,
            verbose=1
        ),
        ModelCheckpoint(
            filepath=model_path,
            monitor="val_auc",
            save_best_only=True,
            mode="max",
            verbose=1
        )
    ]


# ── Inference Helper ─────────────────────────────────────────────────────────
def predict_url(model: Model, url: str, features: np.ndarray) -> dict:
    """
    Run inference on a single URL.
    Returns dict with score and label.
    """
    url_seq = urls_to_sequences([url])
    feat_input = features.reshape(1, -1)

    prob = float(model.predict([url_seq, feat_input], verbose=0)[0][0])
    label = "PHISHING" if prob >= 0.5 else "LEGITIMATE"

    return {
        "url": url,
        "phishing_probability": round(prob, 4),
        "label": label,
        "confidence": round(max(prob, 1 - prob) * 100, 1)
    }


if __name__ == "__main__":
    model = build_model()
    model.summary()
    print(f"\nTotal parameters: {model.count_params():,}")
