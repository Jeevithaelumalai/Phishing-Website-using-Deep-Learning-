"""
PhishGuard - Feature Extractor
Extracts 30 features from a URL for phishing detection.
"""

import re
import urllib.parse
from typing import List


# Known shortening services
SHORTENING_SERVICES = {
    "bit.ly", "tinyurl.com", "goo.gl", "ow.ly", "t.co",
    "is.gd", "buff.ly", "adf.ly", "su.pr", "tr.im"
}

# Suspicious TLDs often used in phishing
SUSPICIOUS_TLDS = {
    ".xyz", ".tk", ".ml", ".ga", ".cf", ".gq",
    ".top", ".club", ".work", ".loan", ".click"
}

# Brands commonly targeted by phishing
TARGET_BRANDS = [
    "paypal", "google", "apple", "microsoft", "amazon",
    "facebook", "instagram", "netflix", "bank", "secure",
    "login", "signin", "verify", "account", "update",
    "confirm", "support", "service", "billing"
]


def extract_features(url: str) -> List[float]:
    """
    Extract 30 numerical features from a URL.
    Returns a list of floats (all binary or normalized).
    """
    features = []

    try:
        parsed = urllib.parse.urlparse(url)
        domain = parsed.netloc.lower()
        path = parsed.path.lower()
        full_url = url.lower()
        hostname = domain.replace("www.", "")
    except Exception:
        return [0.0] * 30

    # ── URL Structure Features ──────────────────────────────────────────────

    # 1. URL Length (normalized: >75 chars = 1)
    features.append(1.0 if len(url) > 75 else 0.0)

    # 2. Hostname Length (>20 = suspicious)
    features.append(1.0 if len(hostname) > 20 else 0.0)

    # 3. Number of dots in hostname
    features.append(min(domain.count(".") / 5.0, 1.0))

    # 4. Number of hyphens in hostname
    features.append(1.0 if hostname.count("-") > 1 else 0.0)

    # 5. Number of underscores in URL
    features.append(1.0 if url.count("_") > 0 else 0.0)

    # 6. Number of slashes in path
    features.append(min(path.count("/") / 10.0, 1.0))

    # 7. Number of "@" symbols (used to trick browser)
    features.append(1.0 if "@" in url else 0.0)

    # 8. Has "//" in path (redirection trick)
    features.append(1.0 if "//" in path else 0.0)

    # 9. URL has port number
    features.append(1.0 if parsed.port is not None else 0.0)

    # 10. Number of query parameters
    params = urllib.parse.parse_qs(parsed.query)
    features.append(min(len(params) / 10.0, 1.0))

    # ── Protocol & Security Features ────────────────────────────────────────

    # 11. Uses HTTPS
    features.append(1.0 if parsed.scheme == "https" else 0.0)

    # 12. Has IP address instead of domain name
    ip_pattern = re.compile(r"\d{1,3}(\.\d{1,3}){3}")
    features.append(1.0 if ip_pattern.search(hostname) else 0.0)

    # 13. URL contains hex encoding
    features.append(1.0 if re.search(r"%[0-9a-fA-F]{2}", url) else 0.0)

    # 14. URL contains obfuscation (long digit strings)
    features.append(1.0 if re.search(r"\d{5,}", url) else 0.0)

    # ── Domain-Based Features ────────────────────────────────────────────────

    # 15. Uses a URL shortening service
    features.append(1.0 if any(s in hostname for s in SHORTENING_SERVICES) else 0.0)

    # 16. Suspicious TLD
    features.append(1.0 if any(full_url.endswith(tld) or (tld + "/") in full_url
                                for tld in SUSPICIOUS_TLDS) else 0.0)

    # 17. Number of subdomains (>2 = suspicious)
    subdomain_count = len(hostname.split(".")) - 2
    features.append(1.0 if subdomain_count > 1 else 0.0)

    # 18. Domain contains numbers
    features.append(1.0 if re.search(r"\d", hostname.split(".")[0]) else 0.0)

    # 19. Domain length (first part, >15 chars suspicious)
    first_part = hostname.split(".")[0] if "." in hostname else hostname
    features.append(1.0 if len(first_part) > 15 else 0.0)

    # ── Brand Impersonation Features ────────────────────────────────────────

    # 20. Brand keyword in subdomain (not in registered domain)
    parts = hostname.split(".")
    subdomain_str = ".".join(parts[:-2]) if len(parts) > 2 else ""
    features.append(1.0 if any(b in subdomain_str for b in TARGET_BRANDS) else 0.0)

    # 21. Brand keyword in path
    features.append(1.0 if any(b in path for b in TARGET_BRANDS) else 0.0)

    # 22. Suspicious keywords in full URL
    suspicious_words = ["secure", "login", "signin", "verify", "update", "confirm",
                        "account", "free", "bonus", "lucky", "prize", "winner"]
    features.append(1.0 if any(w in full_url for w in suspicious_words) else 0.0)

    # 23. Multiple brand names in same URL
    brand_hits = sum(1 for b in TARGET_BRANDS if b in full_url)
    features.append(1.0 if brand_hits > 1 else 0.0)

    # ── Special Character Features ───────────────────────────────────────────

    # 24. Count of special chars in URL (normalized)
    special_chars = re.findall(r"[~`!#$%^&*+=\[\]\\';,/{}|\":<>?]", url)
    features.append(min(len(special_chars) / 20.0, 1.0))

    # 25. Has "?" (query string exists)
    features.append(1.0 if "?" in url else 0.0)

    # 26. Has "#" (anchor/fragment)
    features.append(1.0 if "#" in url else 0.0)

    # 27. Ratio of digits to total URL length
    digit_count = sum(1 for c in url if c.isdigit())
    features.append(digit_count / max(len(url), 1))

    # ── Path-Level Features ──────────────────────────────────────────────────

    # 28. Path depth (>4 levels suspicious)
    depth = len([p for p in path.split("/") if p])
    features.append(1.0 if depth > 4 else 0.0)

    # 29. File extension is executable/dangerous
    dangerous_ext = [".exe", ".bat", ".php", ".js", ".zip", ".jar", ".apk"]
    features.append(1.0 if any(path.endswith(e) for e in dangerous_ext) else 0.0)

    # 30. URL entropy (randomness — phishing URLs often have high entropy)
    import math
    if len(url) > 0:
        freq = {}
        for c in url:
            freq[c] = freq.get(c, 0) + 1
        entropy = -sum((f / len(url)) * math.log2(f / len(url)) for f in freq.values())
        features.append(min(entropy / 6.0, 1.0))  # max entropy ~6 for typical URLs
    else:
        features.append(0.0)

    return features


def get_feature_names() -> List[str]:
    """Returns the name of each feature for explainability."""
    return [
        "url_length", "hostname_length", "dot_count", "hyphen_count",
        "underscore_count", "slash_count", "at_symbol", "double_slash",
        "has_port", "query_param_count",
        "uses_https", "has_ip_address", "has_hex_encoding", "has_long_digits",
        "is_url_shortener", "suspicious_tld", "subdomain_depth",
        "domain_has_numbers", "long_first_domain_part",
        "brand_in_subdomain", "brand_in_path", "suspicious_keywords",
        "multiple_brands",
        "special_char_count", "has_query_string", "has_anchor",
        "digit_ratio",
        "deep_path", "dangerous_extension", "url_entropy"
    ]


if __name__ == "__main__":
    # Quick test
    test_urls = [
        "https://www.google.com/search?q=weather",
        "http://paypal-secure-login.xyz/verify/account?id=123456",
        "http://192.168.1.1/login.php",
        "https://bit.ly/3xAbc12",
    ]

    names = get_feature_names()
    for url in test_urls:
        feats = extract_features(url)
        score = sum(feats)
        print(f"\nURL: {url}")
        print(f"  Phishing score: {score:.1f}/30")
        flagged = [names[i] for i, v in enumerate(feats) if v > 0.5]
        print(f"  Flagged features: {flagged}")
