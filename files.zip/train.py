"""
PhishGuard - Training Pipeline
Downloads data, extracts features, trains model, saves weights.

Usage:
    python src/train.py
    python src/train.py --epochs 30 --batch-size 64
"""

import argparse
import os
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import urllib.request

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.feature_extractor import extract_features, get_feature_names
from src.model import build_model, urls_to_sequences, get_callbacks, MODEL_SAVE_PATH


# ── Data Loading ──────────────────────────────────────────────────────────────

DATASET_URL = "https://raw.githubusercontent.com/ebubekirbbr/pdd/master/input/train.csv"
LOCAL_DATA_PATH = "data/phishing_dataset.csv"


def load_or_download_data() -> pd.DataFrame:
    """
    Load dataset. Falls back to generating synthetic data if download fails.
    Real dataset columns expected: 'url', 'label' (0=legit, 1=phishing)
    """
    if os.path.exists(LOCAL_DATA_PATH):
        print(f"✅ Loading local dataset: {LOCAL_DATA_PATH}")
        df = pd.read_csv(LOCAL_DATA_PATH)
    else:
        print(f"📥 Downloading dataset...")
        os.makedirs("data", exist_ok=True)
        try:
            urllib.request.urlretrieve(DATASET_URL, LOCAL_DATA_PATH)
            df = pd.read_csv(LOCAL_DATA_PATH)
            print(f"✅ Downloaded {len(df):,} samples")
        except Exception as e:
            print(f"⚠️  Download failed ({e}). Generating synthetic dataset...")
            df = generate_synthetic_data(n=5000)

    # Normalize column names
    df.columns = [c.lower().strip() for c in df.columns]
    if "label" not in df.columns:
        # Try to find label column
        for col in ["status", "type", "class", "result", "phishing"]:
            if col in df.columns:
                df["label"] = df[col]
                break

    # Normalize labels to 0/1
    if df["label"].dtype == object:
        df["label"] = df["label"].map(
            lambda x: 1 if str(x).lower() in ["phishing", "1", "bad", "malicious"] else 0
        )

    df = df.dropna(subset=["url", "label"])
    df["label"] = df["label"].astype(int)
    return df


def generate_synthetic_data(n: int = 5000) -> pd.DataFrame:
    """Generate synthetic phishing/legit URLs for demo purposes."""
    import random
    import string

    legit_domains = [
        "google.com", "amazon.com", "microsoft.com", "apple.com",
        "github.com", "stackoverflow.com", "wikipedia.org", "youtube.com",
        "linkedin.com", "reddit.com", "twitter.com", "facebook.com"
    ]
    legit_paths = ["/", "/search", "/about", "/contact", "/products", "/blog"]

    phishing_patterns = [
        "http://paypal-secure-{}.xyz/login/verify",
        "http://192.168.{}.{}/account/confirm",
        "http://secure-{}-update.tk/signin",
        "http://www.{}-login-verify.ml/update/account",
        "http://bit.ly/{}",
        "http://google.com.{}.ru/verify",
    ]

    rows = []
    for _ in range(n // 2):
        domain = random.choice(legit_domains)
        path = random.choice(legit_paths)
        rows.append({"url": f"https://www.{domain}{path}", "label": 0})

    for _ in range(n // 2):
        pattern = random.choice(phishing_patterns)
        rand_str = "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
        url = pattern.format(rand_str, random.randint(1, 255))
        rows.append({"url": url, "label": 1})

    df = pd.DataFrame(rows).sample(frac=1).reset_index(drop=True)
    df.to_csv(LOCAL_DATA_PATH, index=False)
    print(f"✅ Generated {len(df):,} synthetic samples → {LOCAL_DATA_PATH}")
    return df


# ── Feature Extraction ────────────────────────────────────────────────────────

def prepare_inputs(urls, labels):
    """Extract all inputs needed for the dual-input model."""
    print("🔧 Extracting features...")
    features = np.array([extract_features(u) for u in urls], dtype=np.float32)

    print("🔤 Tokenizing URLs...")
    url_seqs = urls_to_sequences(urls)

    return url_seqs, features, np.array(labels, dtype=np.float32)


# ── Evaluation & Visualization ────────────────────────────────────────────────

def plot_training_history(history, save_path="models/training_history.png"):
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    fig.suptitle("PhishGuard Training History", fontsize=14, fontweight="bold")

    # Loss
    axes[0].plot(history.history["loss"], label="Train")
    axes[0].plot(history.history["val_loss"], label="Val")
    axes[0].set_title("Loss")
    axes[0].legend()

    # Accuracy
    axes[1].plot(history.history["accuracy"], label="Train")
    axes[1].plot(history.history["val_accuracy"], label="Val")
    axes[1].set_title("Accuracy")
    axes[1].legend()

    # AUC
    axes[2].plot(history.history["auc"], label="Train")
    axes[2].plot(history.history["val_auc"], label="Val")
    axes[2].set_title("AUC")
    axes[2].legend()

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    print(f"📊 Training history saved → {save_path}")


def plot_confusion_matrix(y_true, y_pred, save_path="models/confusion_matrix.png"):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["Legitimate", "Phishing"],
        yticklabels=["Legitimate", "Phishing"]
    )
    plt.title("PhishGuard Confusion Matrix", fontweight="bold")
    plt.ylabel("True Label")
    plt.xlabel("Predicted Label")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    print(f"📊 Confusion matrix saved → {save_path}")


# ── Main Training Loop ────────────────────────────────────────────────────────

def train(epochs: int = 20, batch_size: int = 32, test_size: float = 0.2):
    print("\n" + "="*55)
    print("  🛡️  PhishGuard - Model Training Pipeline")
    print("="*55 + "\n")

    # 1. Load data
    df = load_or_download_data()
    print(f"\n📦 Dataset: {len(df):,} samples")
    print(f"   Phishing: {df['label'].sum():,} ({df['label'].mean()*100:.1f}%)")
    print(f"   Legit:    {(1-df['label']).sum():,} ({(1-df['label'].mean())*100:.1f}%)\n")

    urls = df["url"].tolist()
    labels = df["label"].tolist()

    # 2. Split data
    (urls_train, urls_test,
     labels_train, labels_test) = train_test_split(
        urls, labels, test_size=test_size,
        random_state=42, stratify=labels
    )

    # 3. Prepare inputs
    X_url_train, X_feat_train, y_train = prepare_inputs(urls_train, labels_train)
    X_url_test,  X_feat_test,  y_test  = prepare_inputs(urls_test,  labels_test)

    print(f"\n✅ Training samples: {len(y_train):,}")
    print(f"✅ Test samples:     {len(y_test):,}\n")

    # 4. Build model
    model = build_model()
    model.summary()

    # 5. Train
    print(f"\n🚀 Training for up to {epochs} epochs...\n")
    history = model.fit(
        x=[X_url_train, X_feat_train],
        y=y_train,
        validation_split=0.15,
        epochs=epochs,
        batch_size=batch_size,
        callbacks=get_callbacks(MODEL_SAVE_PATH),
        verbose=1
    )

    # 6. Evaluate
    print("\n📈 Evaluating on test set...")
    results = model.evaluate(
        [X_url_test, X_feat_test], y_test, verbose=0
    )
    metric_names = ["loss", "accuracy", "auc", "precision", "recall"]
    print("\n── Test Metrics ──────────────────────")
    for name, val in zip(metric_names, results):
        print(f"   {name:12s}: {val:.4f}")

    # F1 score
    y_pred = (model.predict([X_url_test, X_feat_test], verbose=0) >= 0.5).astype(int).flatten()
    print("\n── Classification Report ─────────────")
    print(classification_report(y_test, y_pred, target_names=["Legitimate", "Phishing"]))

    # 7. Save plots
    os.makedirs("models", exist_ok=True)
    plot_training_history(history)
    plot_confusion_matrix(y_test, y_pred)

    print(f"\n✅ Model saved → {MODEL_SAVE_PATH}")
    print("🎉 Training complete!\n")

    return model, history


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train PhishGuard model")
    parser.add_argument("--epochs", type=int, default=20, help="Max training epochs")
    parser.add_argument("--batch-size", type=int, default=32, help="Batch size")
    parser.add_argument("--test-size", type=float, default=0.2, help="Test split ratio")
    args = parser.parse_args()

    train(epochs=args.epochs, batch_size=args.batch_size, test_size=args.test_size)
